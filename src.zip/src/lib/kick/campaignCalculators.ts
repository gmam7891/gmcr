import { safeDivide, clamp } from "@/lib/safeMath";
import type { KickCampaignType } from "./campaignTypes";

interface CampaignInputs extends Record<string, number> {
  followers: number;
  avgCCV: number; // Average Concurrent Viewers
  influencerFee: number;
  engagementRate: number;
  deliveries: number; // Number of streams/hours
  avgViews: number; // Average views per stream
}

export function calculateKickCampaign(type: KickCampaignType, inputs: CampaignInputs): Record<string, number> {
  const { followers, avgCCV, influencerFee, engagementRate, deliveries, avgViews } = inputs;

  const results: Record<string, number> = {};

  // Base metrics for all campaigns
  const baseReach = avgCCV * deliveries; // Simple estimation of total reach based on CCV and number of streams
  const totalViews = avgViews * deliveries; // Total views across all streams

  switch (type) {
    case "igaming": {
      const { cpa, cvr, valueFtd, percIcp } = inputs;

      const potentialConversions = safeDivide(baseReach * (percIcp / 100) * (cvr / 100), 1);
      results.revenue = potentialConversions * valueFtd;
      results.roi = safeDivide((results.revenue - influencerFee) * 100, influencerFee);
      results.cpa = safeDivide(influencerFee, potentialConversions);
      results.profit = results.revenue - influencerFee;
      results.maxFeeRecommended = safeDivide(results.revenue, 3); // Max fee is 1/3 of estimated revenue
      break;
    }
    case "awareness": {
      const { cpm, frequency } = inputs;

      results.uniqueReach = baseReach; // Using baseReach as unique reach for simplicity
      results.totalImpressions = results.uniqueReach * frequency;
      results.cpmCalculated = safeDivide(influencerFee * 1000, results.totalImpressions);
      results.costPerReach = safeDivide(influencerFee, results.uniqueReach);
      break;
    }
    case "consideration": {
      const { ctr, cpc, engagementRateTarget } = inputs;

      results.clicks = baseReach * (ctr / 100);
      results.cpcCalculated = safeDivide(influencerFee, results.clicks);

      const engagementScore = clamp(safeDivide(engagementRate, engagementRateTarget) * 100, 0, 100);
      const ctrScore = clamp(safeDivide(ctr, 5) * 100, 0, 100); // Assuming 5% CTR is good
      results.considerationScore = (engagementScore * 0.6) + (ctrScore * 0.4); // Weighted score
      break;
    }
    case "conversion": {
      const { cvr, valuePerConversion, cpaTarget } = inputs;

      const potentialClicks = baseReach * (inputs.ctr / 100 || 0.05); // Assuming a default CTR if not provided
      results.conversions = potentialClicks * (cvr / 100);
      results.revenue = results.conversions * valuePerConversion;
      results.roi = safeDivide((results.revenue - influencerFee) * 100, influencerFee);
      results.cpaCalculated = safeDivide(influencerFee, results.conversions);
      break;
    }
    case "retention": {
      const { retentionRate, ltv, cac } = inputs;

      const initialConversions = baseReach * (inputs.cvr / 100 || 0.01); // Assuming a default CVR if not provided
      results.retainedUsers = initialConversions * (retentionRate / 100);
      results.ltvTotal = results.retainedUsers * ltv;
      results.roi = safeDivide((results.ltvTotal - influencerFee) * 100, influencerFee);
      results.paybackMonths = safeDivide(influencerFee, (ltv - cac));
      break;
    }
  }

  return results;
}
