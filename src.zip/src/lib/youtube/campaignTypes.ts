import type { InsightLevel } from "@/lib/instagram/campaignTypes"; // Reusing common types

export type YoutubeCampaignType = "igaming" | "awareness" | "consideration" | "conversion" | "retention";

export interface FieldDef {
  key: string;
  label: string;
  type: "number" | "percent" | "currency";
  defaultValue?: number;
  min?: number;
  max?: number;
  step?: number;
  helperText?: string;
}

export interface ResultCardDef {
  key: string;
  label: string;
  format: "currency" | "percent" | "integer" | "decimal" | "months";
  highlight?: boolean;
}

export interface InsightRule {
  title: string;
  description: string;
  level: InsightLevel;
  condition: (results: Record<string, number>, inputs: Record<string, number>) => boolean;
}

export interface YoutubeCampaignConfig {
  label: string;
  icon: string;
  fields: FieldDef[];
  resultCards: ResultCardDef[];
  insightRules: InsightRule[];
}
