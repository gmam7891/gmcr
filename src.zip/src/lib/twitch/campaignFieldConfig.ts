import type { TwitchCampaignType, TwitchCampaignConfig } from "./campaignTypes";
import type { TFunction } from "i18next";

export function getCampaignConfigs(t: TFunction): Record<TwitchCampaignType, TwitchCampaignConfig> {
  return {
    igaming: {
      label: t("campaign_type.igaming"),
      icon: "🎰",
      fields: [
        { key: "cpa", label: t("field.cpa"), type: "currency", defaultValue: 100, step: 10 },
        { key: "cvr", label: t("field.cvr"), type: "percent", defaultValue: 1, step: 0.1 },
        { key: "valueFtd", label: t("field.value_ftd"), type: "currency", defaultValue: 200, step: 10 },
        { key: "percIcp", label: t("field.perc_icp"), type: "percent", defaultValue: 50, step: 1 },
      ],
      resultCards: [
        { key: "revenue", label: t("result.revenue"), format: "currency", highlight: true },
        { key: "roi", label: t("result.roi"), format: "percent", highlight: true },
        { key: "cpa", label: t("result.cpa"), format: "currency" },
        { key: "profit", label: t("result.profit"), format: "currency" },
        { key: "maxFeeRecommended", label: t("result.max_fee_recommended"), format: "currency" },
      ],
      insightRules: [
        { title: t("insight.igaming.high_roi.title"), description: t("insight.igaming.high_roi.desc"), level: "positive", condition: (r) => r.roi >= 200 },
        { title: t("insight.igaming.low_cpa.title"), description: t("insight.igaming.low_cpa.desc"), level: "positive", condition: (r) => r.cpa <= 50 },
        { title: t("insight.igaming.moderate_roi.title"), description: t("insight.igaming.moderate_roi.desc"), level: "neutral", condition: (r) => r.roi >= 100 && r.roi < 200 },
        { title: t("insight.igaming.high_cpa.title"), description: t("insight.igaming.high_cpa.desc"), level: "warning", condition: (r) => r.cpa > 150 },
        { title: t("insight.igaming.negative_roi.title"), description: t("insight.igaming.negative_roi.desc"), level: "warning", condition: (r) => r.roi < 0 },
      ],
    },
    awareness: {
      label: t("campaign_type.awareness"),
      icon: "📢",
      fields: [
        { key: "cpm", label: t("field.cpm"), type: "currency", defaultValue: 5, step: 0.1 },
        { key: "frequency", label: t("field.frequency"), type: "number", defaultValue: 1.5, step: 0.1 },
      ],
      resultCards: [
        { key: "uniqueReach", label: t("result.unique_reach"), format: "integer", highlight: true },
        { key: "totalImpressions", label: t("result.total_impressions"), format: "integer", highlight: true },
        { key: "cpmCalculated", label: t("result.cpm_calculated"), format: "currency" },
        { key: "costPerReach", label: t("result.cost_per_reach"), format: "currency" },
      ],
      insightRules: [
        { title: t("insight.awareness.high_reach.title"), description: t("insight.awareness.high_reach.desc"), level: "positive", condition: (r) => r.uniqueReach >= 100000 },
        { title: t("insight.awareness.low_cpm.title"), description: t("insight.awareness.low_cpm.desc"), level: "positive", condition: (r) => r.cpmCalculated <= 3 },
        { title: t("insight.awareness.moderate_reach.title"), description: t("insight.awareness.moderate_reach.desc"), level: "neutral", condition: (r) => r.uniqueReach >= 50000 && r.uniqueReach < 100000 },
        { title: t("insight.awareness.high_cpm.title"), description: t("insight.awareness.high_cpm.desc"), level: "warning", condition: (r) => r.cpmCalculated > 7 },
      ],
    },
    consideration: {
      label: t("campaign_type.consideration"),
      icon: "🧠",
      fields: [
        { key: "ctr", label: t("field.ctr"), type: "percent", defaultValue: 5, step: 0.1 },
        { key: "cpc", label: t("field.cpc"), type: "currency", defaultValue: 0.5, step: 0.01 },
        { key: "engagementRateTarget", label: t("field.engagement_rate_target"), type: "percent", defaultValue: 3, step: 0.1 },
      ],
      resultCards: [
        { key: "clicks", label: t("result.clicks"), format: "integer", highlight: true },
        { key: "cpcCalculated", label: t("result.cpc_calculated"), format: "currency" },
        { key: "considerationScore", label: t("result.consideration_score"), format: "integer", highlight: true },
      ],
      insightRules: [
        { title: t("insight.consideration.high_score.title"), description: t("insight.consideration.high_score.desc"), level: "positive", condition: (r) => r.considerationScore >= 70 },
        { title: t("insight.consideration.low_cpc.title"), description: t("insight.consideration.low_cpc.desc"), level: "positive", condition: (r) => r.cpcCalculated <= 0.3 },
        { title: t("insight.consideration.moderate_score.title"), description: t("insight.consideration.moderate_score.desc"), level: "neutral", condition: (r) => r.considerationScore >= 40 && r.considerationScore < 70 },
        { title: t("insight.consideration.high_cpc.title"), description: t("insight.consideration.high_cpc.desc"), level: "warning", condition: (r) => r.cpcCalculated > 0.8 },
      ],
    },
    conversion: {
      label: t("campaign_type.conversion"),
      icon: "🎯",
      fields: [
        { key: "cvr", label: t("field.cvr"), type: "percent", defaultValue: 1, step: 0.1 },
        { key: "valuePerConversion", label: t("field.value_per_conversion"), type: "currency", defaultValue: 50, step: 5 },
        { key: "cpaTarget", label: t("field.cpa_target"), type: "currency", defaultValue: 20, step: 1 },
      ],
      resultCards: [
        { key: "conversions", label: t("result.conversions"), format: "integer", highlight: true },
        { key: "revenue", label: t("result.revenue"), format: "currency", highlight: true },
        { key: "cpaCalculated", label: t("result.cpa_calculated"), format: "currency" },
        { key: "roi", label: t("result.roi"), format: "percent" },
      ],
      insightRules: [
        { title: t("insight.conversion.high_roi.title"), description: t("insight.conversion.high_roi.desc"), level: "positive", condition: (r) => r.roi >= 200 },
        { title: t("insight.conversion.low_cpa.title"), description: t("insight.conversion.low_cpa.desc"), level: "positive", condition: (r) => r.cpaCalculated <= 15 },
        { title: t("insight.conversion.moderate_roi.title"), description: t("insight.conversion.moderate_roi.desc"), level: "neutral", condition: (r) => r.roi >= 100 && r.roi < 200 },
        { title: t("insight.conversion.high_cpa.title"), description: t("insight.conversion.high_cpa.desc"), level: "warning", condition: (r) => r.cpaCalculated > 30 },
      ],
    },
    retention: {
      label: t("campaign_type.retention"),
      icon: "🔄",
      fields: [
        { key: "retentionRate", label: t("field.retention_rate"), type: "percent", defaultValue: 50, step: 1 },
        { key: "ltv", label: t("field.ltv"), type: "currency", defaultValue: 100, step: 10 },
        { key: "cac", label: t("field.cac"), type: "currency", defaultValue: 30, step: 1 },
      ],
      resultCards: [
        { key: "retainedUsers", label: t("result.retained_users"), format: "integer", highlight: true },
        { key: "ltvTotal", label: t("result.ltv_total"), format: "currency", highlight: true },
        { key: "roi", label: t("result.roi"), format: "percent" },
        { key: "paybackMonths", label: t("result.payback_months"), format: "months" },
      ],
      insightRules: [
        { title: t("insight.retention.high_roi.title"), description: t("insight.retention.high_roi.desc"), level: "positive", condition: (r) => r.roi >= 200 },
        { title: t("insight.retention.low_payback.title"), description: t("insight.retention.low_payback.desc"), level: "positive", condition: (r) => r.paybackMonths <= 3 },
        { title: t("insight.retention.moderate_roi.title"), description: t("insight.retention.moderate_roi.desc"), level: "neutral", condition: (r) => r.roi >= 100 && r.roi < 200 },
        { title: t("insight.retention.high_cac.title"), description: t("insight.retention.high_cac.desc"), level: "warning", condition: (r) => r.cac > 50 },
      ],
    },
  };
}
