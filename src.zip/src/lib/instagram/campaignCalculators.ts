import { safeDivide, clamp } from "@/lib/safeMath";
import type { CampaignType } from "./campaignTypes";

type Inputs = Record<string, number>;

/**
 * REVAMPED: Calculates the total unique audience reached by the campaign.
 * This function now correctly interprets the base inputs as reach per content piece.
 */
function getUniqueReach(inputs: Inputs): number {
  const avgReachPerContent = inputs.avgReach || 0;
  const totalDeliveries = (inputs.reelsDeliveries || 0) + (inputs.storiesDeliveries || 0);

  // A simple model assuming some audience overlap between content pieces.
  // Using a diminishing return factor for each delivery.
  if (totalDeliveries <= 1) {
    return avgReachPerContent;
  }
  // A more realistic model than simple multiplication, assumes overlap.
  // Example: 1 - (1 - 0.1)^5 for 10% reach over 5 posts.
  const nonOverlapFactor = 0.8; // Assume 20% overlap between posts
  return avgReachPerContent * (1 + (totalDeliveries - 1) * nonOverlapFactor);
}

/**
 * REVAMPED: Calculates the total impressions of the campaign.
 */
function getTotalImpressions(inputs: Inputs): number {
  const reelsImpressions = (inputs.reelsViews || 0) * Math.max(inputs.reelsDeliveries || 0, 1);
  const storiesImpressions = (inputs.storiesViews || 0) * Math.max(inputs.storiesDeliveries || 0, 1);
  const totalCalculatedImpressions = reelsImpressions + storiesImpressions;

  // If a specific frequency is provided, use it with the unique reach.
  const uniqueReach = getUniqueReach(inputs);
  const frequency = Math.max(inputs.averageFrequency || 1, 1);
  const impressionsFromFrequency = uniqueReach * frequency;

  // Prefer the more detailed calculation if available, otherwise use the frequency-based one.
  return totalCalculatedImpressions > 0 ? totalCalculatedImpressions : impressionsFromFrequency;
}

/**
 * REVAMPED: Calculates the average audience for a single piece of content.
 * Prioritizes the most reliable metric available (avgReach).
 */
function getBasePerContent(inputs: Inputs): number {
  const reach = inputs.avgReach || 0;
  if (reach > 0) return reach;

  // Fallback to averaging views if reach is not provided.
  const reelsViews = inputs.reelsViews || 0;
  const storiesViews = inputs.storiesViews || 0;
  const numViewSources = (reelsViews > 0 ? 1 : 0) + (storiesViews > 0 ? 1 : 0);
  
  return numViewSources > 0 ? (reelsViews + storiesViews) / numViewSources : 0;
}

const calculators: Record<CampaignType, (inputs: Inputs) => Record<string, number>> = {
  igaming: (i) => {
    const base = getBasePerContent(i);
    const qualifiedAudience = base * (i.icpPercent / 100);
    const estimatedClicks = qualifiedAudience * (i.estimatedCtr / 100);
    const estimatedRegistrations = estimatedClicks * (i.registrationRate / 100);
    const estimatedFtds = estimatedRegistrations * (i.ftdRate / 100);
    const estimatedRevenue = estimatedFtds * i.valuePerFtd;
    const estimatedCpa = safeDivide(i.influencerFee, estimatedFtds);
    const estimatedRoi = safeDivide((estimatedRevenue - i.influencerFee), i.influencerFee) * 100;
    const recommendedMaxFee = estimatedRevenue / 3; // Business rule: pay 1/3 of expected revenue

    return {
      qualifiedAudience, estimatedClicks, estimatedRegistrations,
      estimatedFtds, estimatedRevenue,
      estimatedCpa, estimatedRoi, recommendedMaxFee,
    };
  },

  awareness: (i) => {
    const estimatedUniqueReach = getUniqueReach(i);
    const estimatedImpressions = getTotalImpressions(i);
    const freq = safeDivide(estimatedImpressions, estimatedUniqueReach, 1); // Calculate frequency dynamically
    const qualifiedReach = estimatedUniqueReach * (i.icpPercent / 100);
    const realCpm = safeDivide(i.influencerFee * 1000, estimatedImpressions);
    const costPerReachedUser = safeDivide(i.influencerFee, estimatedUniqueReach);
    const qualifiedCpm = safeDivide(i.influencerFee * 1000, qualifiedReach);

    return {
      estimatedImpressions, estimatedUniqueReach, qualifiedReach,
      averageFrequency: freq, realCpm, costPerReachedUser, qualifiedCpm,
    };
  },

  consideration: (i) => {
    const base = getBasePerContent(i);
    const qualifiedAudience = base * (i.icpPercent / 100);
    const estimatedClicks = qualifiedAudience * (i.estimatedCtr / 100);
    // Use a more specific engagement rate if available, otherwise fallback to total
    const engagementInput = i.reelsEngagement || i.storiesEngagement || i.engagementRate || 0;
    const engagedUsers = qualifiedAudience * (engagementInput / 100);
    const qualifiedTraffic = estimatedClicks * (i.contentRetentionRate / 100);
    const estimatedCpc = safeDivide(i.influencerFee, estimatedClicks);
    const costPerEngagedUser = safeDivide(i.influencerFee, engagedUsers);
    const considerationScore = clamp(
      (i.estimatedCtr * 0.4) + (i.contentRetentionRate * 0.4) + (engagementInput * 0.2),
      0, 100
    );

    return {
      estimatedClicks, engagedUsers, qualifiedTraffic,
      estimatedCpc, costPerEngagedUser, considerationScore,
      contentRetentionRate: i.contentRetentionRate,
    };
  },

  conversion: (i) => {
    const uniqueReach = getUniqueReach(i);
    const qualifiedAudience = uniqueReach * (i.icpPercent / 100);
    const estimatedClicks = qualifiedAudience * (i.estimatedCtr / 100);
    const estimatedConversions = estimatedClicks * (i.finalConversionRate / 100);
    const grossRevenue = estimatedConversions * i.valuePerConversion;
    const estimatedRevenue = grossRevenue * (i.conversionMargin > 0 ? i.conversionMargin / 100 : 1);
    const costPerConversion = safeDivide(i.influencerFee, estimatedConversions);
    const estimatedRoi = safeDivide((estimatedRevenue - i.influencerFee), i.influencerFee) * 100;
    const estimatedRoas = safeDivide(estimatedRevenue, i.influencerFee);

    return {
      estimatedClicks, estimatedConversions, estimatedRevenue,
      costPerConversion, estimatedRoi, estimatedRoas,
    };
  },

  retention: (i) => {
    const base = getBasePerContent(i);
    const qualifiedAudience = base * (i.icpPercent / 100);
    const retainedUsers = qualifiedAudience * (i.repurchaseRate / 100);
    const reactivatedUsers = qualifiedAudience * (i.reactivationRate / 100);
    const activeUsers = retainedUsers + reactivatedUsers;
    const freq = Math.max(i.repurchaseFrequency || 1, 1);
    const churnFactor = 1 - (i.estimatedChurn / 100);
    const estimatedRecurringRevenue = activeUsers * i.estimatedLtv * freq * churnFactor;
    const costPerRetainedUser = safeDivide(i.influencerFee, activeUsers);
    const retentionRoi = safeDivide((estimatedRecurringRevenue - i.influencerFee), i.influencerFee) * 100;
    const monthlyRevenue = estimatedRecurringRevenue / 12;
    const estimatedPayback = safeDivide(i.influencerFee, monthlyRevenue);

    return {
      retainedUsers, reactivatedUsers, activeUsers,
      estimatedRecurringRevenue, costPerRetainedUser, retentionRoi,
      estimatedPayback, estimatedLtv: i.estimatedLtv, estimatedChurn: i.estimatedChurn,
    };
  },
};

export function calculateCampaign(type: CampaignType, inputs: Inputs): Record<string, number> {
  return calculators[type](inputs);
}
