import { NumberField, FieldSection } from "@/components/FieldGroup";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { fmtInt } from "@/lib/formatters";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";

interface ProfileData {
  login: string;
  displayName: string;
  profilePicUrl: string;
  followers: number;
  avgCCV: number; // Average Concurrent Viewers
  peakViewers: number;
  vodCount: number;
  avgVodViews: number;
  medianVodViews: number;
  vodViewsPerHour: number;
  isLive: boolean;
  gameName: string | null;
}

interface Props {
  values: Record<string, number>;
  onChange: (key: string, value: number) => void;
  channel: string;
  setChannel: (v: string) => void;
}

export function BaseInfluencerFields({ values, onChange, channel, setChannel }: Props) {
  const [loading, setLoading] = useState(false);
  const [profile, setProfile] = useState<ProfileData | null>(null);

  const fetchProfile = async () => {
    if (!channel.trim()) return;
    setLoading(true);
    try {
      // Assuming a Kick API Edge Function exists similar to Twitch
      const { data, error } = await supabase.functions.invoke("kick-api", {
        body: { channelLogin: channel.trim() },
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      const user = data.user;
      const stream = data.stream;
      const vods = data.vods; // Assuming vods data is returned

      let vodStats = {
        count: 0,
        avgViews: 0,
        medianViews: 0,
        vph: 0,
      };

      if (vods && vods.length > 0) {
        const views = vods.map((v: any) => v.views);
        const hours = vods.map((v: any) => v.duration / 3600); // Assuming duration in seconds
        const totalViews = views.reduce((a: number, b: number) => a + b, 0);
        const totalHours = hours.reduce((a: number, b: number) => a + b, 0);
        const sorted = [...views].sort((a, b) => a - b);
        const median = sorted.length % 2 === 0 ? (sorted[sorted.length / 2 - 1] + sorted[sorted.length / 2]) / 2 : sorted[Math.floor(sorted.length / 2)];
        const vph = totalHours > 0 ? totalViews / totalHours : 0;
        vodStats = { count: vods.length, avgViews: totalViews / vods.length, medianViews: median, vph };
      }

      const newProfile: ProfileData = {
        login: user.slug,
        displayName: user.username,
        profilePicUrl: user.profile_pic,
        followers: user.followers_count,
        avgCCV: stream?.viewer_count || 0,
        peakViewers: stream?.viewer_count || 0,
        vodCount: vodStats.count,
        avgVodViews: vodStats.avgViews,
        medianVodViews: vodStats.medianViews,
        vodViewsPerHour: vodStats.vph,
        isLive: !!stream,
        gameName: stream?.category?.name || null,
      };
      setProfile(newProfile);

      // Map to campaign inputs
      onChange("followers", newProfile.followers);
      onChange("avgCCV", newProfile.avgCCV);
      onChange("avgViews", newProfile.avgVodViews); // Using avgVodViews as avgViews for campaign
      onChange("vodViewsPerHour", newProfile.vodViewsPerHour);

      toast.success(`Canal @${newProfile.login} carregado!`, {
        description: `${fmtInt(newProfile.followers)} seguidores · ${fmtInt(newProfile.avgCCV)} CCV (Live)`,
      });
    } catch (err: any) {
      toast.error("Erro ao buscar canal", { description: err.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-5">
      <FieldSection title="Buscar canal">
        <div className="flex gap-2">
          <Input
            placeholder="@login_do_canal"
            value={channel}
            onChange={(e) => setChannel(e.target.value.toLowerCase().trim())}
            onKeyDown={(e) => e.key === "Enter" && fetchProfile()}
            className="font-mono"
          />
          <Button onClick={fetchProfile} disabled={loading} size="sm" className="shrink-0">
            {loading ? "Buscando…" : "Buscar"}
          </Button>
        </div>
        {profile && (
          <div className="flex items-center gap-3 p-3 rounded-lg bg-secondary/50 border border-border mt-2">
            {profile.profilePicUrl && (
              <img src={profile.profilePicUrl} alt={profile.displayName} className="w-10 h-10 rounded-full" />
            )}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="font-medium text-sm truncate">@{profile.login}</span>
                {profile.isLive && <span className="text-accent text-xs">LIVE</span>}
              </div>
              <span className="text-xs text-muted-foreground">
                {fmtInt(profile.followers)} seg · {fmtInt(profile.avgCCV)} CCV (Live)
              </span>
            </div>
          </div>
        )}
      </FieldSection>

      <FieldSection title="Dados do Influenciador (Kick)">
        <div className="grid grid-cols-2 gap-3">
          <NumberField label="Seguidores totais" value={values.followers} onChange={(v) => onChange("followers", v)} step={1000} />
          <NumberField label="CCV Médio (Live)" value={values.avgCCV} onChange={(v) => onChange("avgCCV", v)} step={100} />
        </div>
        <div className="grid grid-cols-2 gap-3 mt-3">
          <NumberField label="Fee do influenciador" value={values.influencerFee} onChange={(v) => onChange("influencerFee", v)} step={1000} suffix="R$" />
          <NumberField label="Engajamento (Chat/Follow)" value={values.engagementRate} onChange={(v) => onChange("engagementRate", v)} step={0.1} suffix="%" />
        </div>
      </FieldSection>

      <FieldSection title="Entregas · Streams">
        <div className="grid grid-cols-3 gap-3">
          <NumberField label="Horas Contratadas" value={values.deliveries} onChange={(v) => onChange("deliveries", v)} step={1} />
          <NumberField label="Views Médias por VOD" value={values.avgViews} onChange={(v) => onChange("avgViews", v)} step={1000} />
          <NumberField label="VOD Views por Hora" value={values.vodViewsPerHour} onChange={(v) => onChange("vodViewsPerHour", v)} step={10} />
        </div>
      </FieldSection>
    </div>
  );
}
