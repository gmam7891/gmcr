import { NumberField, FieldSection } from "@/components/FieldGroup";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { fmtInt } from "@/lib/formatters";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";

interface ProfileData {
  channelId: string;
  channelName: string;
  profilePicUrl: string;
  subscribers: number;
  totalViews: number;
  videoCount: number;
  avgViewsPerVideo: number;
  engagementRate: number; // Placeholder for now, YouTube API is tricky
}

interface Props {
  values: Record<string, number>;
  onChange: (key: string, value: number) => void;
  channel: string;
  setChannel: (v: string) => void;
}

export function BaseInfluencerFields({ values, onChange, channel, setChannel }: Props) {
  const [loading, setLoading] = useState(false);
  const [profile, setProfile] = useState<ProfileData | null>(null);

  const fetchProfile = async () => {
    if (!channel.trim()) return;
    setLoading(true);
    try {
      // Assuming a YouTube API Edge Function exists similar to Instagram
      const { data, error } = await supabase.functions.invoke("youtube-api", {
        body: { channelName: channel.trim() }, // Or channelId
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      const newProfile: ProfileData = {
        channelId: data.channelId,
        channelName: data.channelName,
        profilePicUrl: data.profilePicUrl,
        subscribers: data.subscribers,
        totalViews: data.totalViews,
        videoCount: data.videoCount,
        avgViewsPerVideo: data.avgViewsPerVideo,
        engagementRate: data.engagementRate || 0, // Default to 0 if not provided by API
      };
      setProfile(newProfile);

      // Map to campaign inputs
      onChange("subscribers", newProfile.subscribers);
      onChange("avgViews", newProfile.avgViewsPerVideo);
      onChange("engagementRate", newProfile.engagementRate);
      onChange("videoDeliveries", newProfile.videoCount); // Assuming videoCount as deliveries

      toast.success(`Canal ${newProfile.channelName} carregado!`, {
        description: `${fmtInt(newProfile.subscribers)} inscritos · ${fmtInt(newProfile.avgViewsPerVideo)} views/vídeo`,
      });
    } catch (err: any) {
      toast.error("Erro ao buscar canal", { description: err.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-5">
      <FieldSection title="Buscar canal">
        <div className="flex gap-2">
          <Input
            placeholder="Nome do Canal ou ID"
            value={channel}
            onChange={(e) => setChannel(e.target.value.trim())}
            onKeyDown={(e) => e.key === "Enter" && fetchProfile()}
            className="font-mono"
          />
          <Button onClick={fetchProfile} disabled={loading} size="sm" className="shrink-0">
            {loading ? "Buscando…" : "Buscar"}
          </Button>
        </div>
        {profile && (
          <div className="flex items-center gap-3 p-3 rounded-lg bg-secondary/50 border border-border mt-2">
            {profile.profilePicUrl && (
              <img src={profile.profilePicUrl} alt={profile.channelName} className="w-10 h-10 rounded-full" />
            )}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="font-medium text-sm truncate">{profile.channelName}</span>
              </div>
              <span className="text-xs text-muted-foreground">
                {fmtInt(profile.subscribers)} inscritos · {fmtInt(profile.avgViewsPerVideo)} views/vídeo
              </span>
            </div>
          </div>
        )}
      </FieldSection>

      <FieldSection title="Dados do Influenciador (YouTube)">
        <div className="grid grid-cols-2 gap-3">
          <NumberField label="Inscritos totais" value={values.subscribers} onChange={(v) => onChange("subscribers", v)} step={1000} />
          <NumberField label="Views médias por vídeo" value={values.avgViews} onChange={(v) => onChange("avgViews", v)} step={1000} />
        </div>
        <div className="grid grid-cols-2 gap-3 mt-3">
          <NumberField label="Fee do influenciador" value={values.influencerFee} onChange={(v) => onChange("influencerFee", v)} step={1000} suffix="R$" />
          <NumberField label="Engajamento (Likes/Comentários)" value={values.engagementRate} onChange={(v) => onChange("engagementRate", v)} step={0.1} suffix="%" />
        </div>
      </FieldSection>

      <FieldSection title="Entregas · Vídeos">
        <div className="grid grid-cols-3 gap-3">
          <NumberField label="Quantidade de Vídeos" value={values.videoDeliveries} onChange={(v) => onChange("videoDeliveries", v)} step={1} />
        </div>
      </FieldSection>
    </div>
  );
}
