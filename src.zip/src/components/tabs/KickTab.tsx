import { useState, useMemo, useCallback } from "react";
import { CampaignTypeSelector } from "@/components/instagram/CampaignTypeSelector"; // Reusing generic selector
import { BaseInfluencerFields } from "@/components/kick/BaseInfluencerFields";
import { DynamicCampaignFields } from "@/components/instagram/DynamicCampaignFields"; // Reusing generic dynamic fields
import { ResultCardsGrid } from "@/components/instagram/ResultCardsGrid"; // Reusing generic result grid
import { InsightCards } from "@/components/instagram/InsightCards"; // Reusing generic insight cards
import { calculateKickCampaign } from "@/lib/kick/campaignCalculators";
import { getCampaignConfigs } from "@/lib/kick/campaignFieldConfig";
import type { KickCampaignType } from "@/lib/kick/campaignTypes";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/LanguageContext";
import * as XLSX from "xlsx";

const BASE_KEYS = [
  "followers", "avgCCV", "influencerFee", "engagementRate",
  "deliveries", "avgViews", "vodViewsPerHour",
];

export function KickTab() {
  const { t } = useLanguage();
  const [campaignType, setCampaignType] = useState<KickCampaignType>("igaming");
  const [channel, setChannel] = useState("");
  const [values, setValues] = useState<Record<string, number>>(() => {
    const init: Record<string, number> = {};
    BASE_KEYS.forEach((k) => (init[k] = 0));
    return init;
  });

  const handleChange = useCallback((key: string, value: number) => {
    setValues((prev) => ({ ...prev, [key]: value }));
  }, []);

  const campaignConfigs = getCampaignConfigs(t);
  const config = campaignConfigs[campaignType];

  const allInputs = useMemo(() => {
    const merged: Record<string, number> = { ...values };
    config.fields.forEach((f) => {
      if (merged[f.key] == null) merged[f.key] = f.defaultValue ?? 0;
    });
    return merged;
  }, [values, config]);

  const results = useMemo(() => calculateKickCampaign(campaignType, allInputs), [campaignType, allInputs]);

  const downloadExcel = () => {
    const rows: (string | number)[][] = [
      ["Campaign type", config.label],
      [""],
      ["Field", "Value"],
      ["Followers", values.followers ?? 0],
      ["Avg CCV", values.avgCCV ?? 0],
      ["Fee", values.influencerFee ?? 0],
      ["Contracted Hours", values.deliveries ?? 0],
      ["Avg VOD Views", values.avgViews ?? 0],
      ["VOD Views per Hour", values.vodViewsPerHour ?? 0],
      ["Engagement (%)", values.engagementRate ?? 0],
      ...config.fields.map((f) => [f.label, values[f.key] ?? f.defaultValue ?? 0]),
      [""],
      ["Result", "Value"],
      ...config.resultCards.map((c) => [c.label, results[c.key] ?? 0]),
    ];
    const ws = XLSX.utils.aoa_to_sheet(rows);
    ws["!cols"] = [{ wch: 30 }, { wch: 20 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Kick Campaign");
    XLSX.writeFile(wb, `campanha-kick-${channel || 'channel'}.xlsx`);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-semibold text-foreground tracking-tight">{t("kick.title")}</h2>
        <p className="text-sm text-muted-foreground mt-1">{t("kick.subtitle")}</p>
      </div>

      <CampaignTypeSelector value={campaignType} onChange={setCampaignType} />

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <BaseInfluencerFields values={values} onChange={handleChange} channel={channel} setChannel={setChannel} />
          <DynamicCampaignFields fields={config.fields} values={values} onChange={handleChange} title={`${t("kick.params")} · ${config.label}`} />
        </div>

        <div className="lg:col-span-3 space-y-5">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">{t("app.results")}</h3>
            <Button variant="outline" size="sm" onClick={downloadExcel}>{t("app.export_excel")}</Button>
          </div>
          <ResultCardsGrid cards={config.resultCards} results={results} fee={values.influencerFee ?? 0} />
          <InsightCards rules={config.insightRules} results={results} inputs={allInputs} />
          <p className="text-xs text-muted-foreground mt-4">{t("kick.calculations_note")}</p>
        </div>
      </div>
    </div>
  );
}
